/* calc.js — fungsi perhitungan murni (tanpa DOM). Satuan SI: V, Hz, Ω, H, F. */
(function (root) {
  'use strict';
  var LIM = { V: [1, 240], f: [1, 1000], R: [1, 1000], L: [1e-3, 10], C: [1e-6, 1e-2] };
  function validate(p) {
    for (var k in LIM) {
      var v = p[k];
      if (typeof v !== 'number' || !isFinite(v)) return 'Nilai ' + k + ' harus berupa angka yang valid.';
      if (v < LIM[k][0] * 0.999999 || v > LIM[k][1] * 1.000001) return 'Nilai ' + k + ' di luar rentang yang diizinkan.';
    }
    return '';
  }
  function f0(L, C) { return 1 / (2 * Math.PI * Math.sqrt(L * C)); }
  function series(p) {
    var w = 2 * Math.PI * p.f, uL = p.useL !== false, uC = p.useC !== false;
    var XL = uL ? w * p.L : 0, XC = uC ? 1 / (w * p.C) : 0, X = XL - XC;
    var Z = Math.hypot(p.R, X), phi = Math.atan2(X, p.R), I = p.V / Z;
    return { mode: 'seri', w: w, XL: XL, XC: XC, X: X, Z: Z, phi: phi, I: I, Ipk: Math.SQRT2 * I,
      VR: I * p.R, VL: I * XL, VC: I * XC, PF: Math.cos(phi),
      P: p.V * I * Math.cos(phi), Q: p.V * I * Math.sin(phi), S: p.V * I,
      f0: uL && uC ? f0(p.L, p.C) : NaN };
  }
  function parallel(p) {
    var w = 2 * Math.PI * p.f, uL = p.useL !== false, uC = p.useC !== false;
    var G = 1 / p.R, BL = uL ? -1 / (w * p.L) : 0, BC = uC ? w * p.C : 0, B = BL + BC;
    var Y = Math.hypot(G, B), Z = 1 / Y, thI = Math.atan2(B, G), phi = -thI;   // arus total = V·Y
    var IR = p.V * G, IL = uL ? p.V / (w * p.L) : 0, IC = uC ? p.V * w * p.C : 0;
    var I = p.V * Y; // = |IR + j(IC - IL)| (jumlah fasor)
    return { mode: 'paralel', w: w, XL: uL ? w * p.L : Infinity, XC: uC ? 1 / (w * p.C) : Infinity,
      G: G, B: B, Y: Y, Z: Z, phi: phi, I: I, Ipk: Math.SQRT2 * I, IR: IR, IL: IL, IC: IC,
      PF: Math.cos(phi), P: p.V * I * Math.cos(phi), Q: p.V * I * Math.sin(phi), S: p.V * I,
      f0: uL && uC ? f0(p.L, p.C) : NaN };
  }
  function calc(mode, p) { return mode === 'paralel' ? parallel(p) : series(p); }
  root.RLC = { LIM: LIM, validate: validate, calc: calc, series: series, parallel: parallel, f0: f0 };
  if (typeof module !== 'undefined') module.exports = root.RLC;
})(typeof window !== 'undefined' ? window : globalThis);
