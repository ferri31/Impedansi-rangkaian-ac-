(() => {
'use strict';
const $ = s => document.querySelector(s), NS = 'http://www.w3.org/2000/svg', D = 180 / Math.PI;
const DEF = { V: 12, f: 50, R: 100, L: 100, Cc: 100 }; // L dalam mH, C dalam µF
const CFG = [['V','Tegangan sumber RMS','V',1,240],['f','Frekuensi','Hz',1,1000],['R','Resistansi R','Ω',1,1000],['L','Induktansi L','mH',1,10000],['Cc','Kapasitansi C','µF',1,10000]];
const S = { ...DEF, mode: 'seri', useL: true, useC: true, run: true, anim: true, speed: 1, th: 0, res: null, p: null, log: [] };
const n = (x, d = 4) => Number.isFinite(x) ? x.toLocaleString('id-ID', { maximumSignificantDigits: d }) : '—';
const deg = r => n(r * D, 4);
const el = (t, a = {}, p) => { const e = document.createElementNS(NS, t); for (const k in a) e.setAttribute(k, a[k]); if (p) p.appendChild(e); return e; };
const syncs = [];
if (matchMedia('(prefers-reduced-motion: reduce)').matches) S.run = false;

/* ---------- kontrol ---------- */
CFG.forEach(([k, lab, u, mn, mx]) => {
  const d = document.createElement('div'); d.className = 'ctl';
  d.innerHTML = `<label for="n_${k}">${lab} (${u})</label><input type="range" min="0" max="1000" step="1" aria-label="${lab} (geser)"><input type="number" id="n_${k}" min="${mn}" max="${mx}" step="any">`;
  $('#controls').appendChild(d);
  const s = d.querySelector('[type=range]'), m = d.querySelector('[type=number]');
  const toS = v => Math.round(1000 * Math.log(v / mn) / Math.log(mx / mn)), fromS = x => mn * Math.pow(mx / mn, x / 1000);
  s.oninput = () => { S[k] = +fromS(+s.value).toPrecision(3); m.value = S[k]; update(); };
  m.oninput = () => {
    const v = parseFloat(m.value);
    if (!(v >= mn && v <= mx)) { err(`${lab} harus berupa angka antara ${mn} dan ${mx} ${u}.`); return; }
    S[k] = v; s.value = toS(v); update();
  };
  syncs.push(() => { s.value = toS(S[k]); m.value = S[k]; });
});
const err = m => { $('#err').textContent = m; };

/* ---------- pembaruan utama ---------- */
function update() {
  err('');
  const p = { V: S.V, f: S.f, R: S.R, L: S.L / 1e3, C: S.Cc * 1e-6, useL: S.useL, useC: S.useC };
  const bad = RLC.validate(p); if (bad) { err(bad); return; }
  S.p = p; S.res = RLC.calc(S.mode, p);
  $('#offNote').textContent = S.useL && S.useC ? '' : S.mode === 'seri'
    ? 'Komponen nonaktif pada rangkaian seri diganti kawat (hubung singkat, reaktansinya 0 Ω).'
    : 'Komponen nonaktif pada rangkaian paralel dilepas (cabang terbuka, arus cabangnya 0 A).';
  cards(); steps(); formulas(); circuit(); wave(); phasor(); charts(); draw();
}

function cards() {
  const r = S.res, p = S.p, ser = r.mode === 'seri';
  const kind = Math.abs(r.phi) < 0.0087 ? 'Resistif (≈ resonansi), PF ≈ 1' : r.phi > 0 ? 'Induktif: arus tertinggal (lagging)' : 'Kapasitif: arus mendahului (leading)';
  const c = [['Frekuensi sudut ω', n(r.w), 'rad/s', 'ω = 2πf'], ['Reaktansi induktif X_L', n(r.XL), 'Ω', 'naik dengan f'], ['Reaktansi kapasitif X_C', n(r.XC), 'Ω', 'turun dengan f']];
  if (ser) c.push(['Impedansi Z', `${n(p.R)} ${r.X < 0 ? '−' : '+'} j${n(Math.abs(r.X))}`, 'Ω', 'Z = R + j(X_L − X_C)']);
  else c.push(['Admitansi Y', `${n(r.G * 1e3)} ${r.B < 0 ? '−' : '+'} j${n(Math.abs(r.B) * 1e3)}`, 'mS', 'Y = 1/R + j(ωC − 1/ωL)']);
  c.push([ser ? '|Z|' : '|Z_eq|', n(r.Z), 'Ω', ''], ['Sudut fase φ', deg(r.phi), '°', kind]);
  c.push([ser ? 'Arus I_RMS' : 'Arus total I_RMS', n(r.I), 'A', ''], ['Arus puncak', n(r.Ipk), 'A', '√2 × I_RMS']);
  if (ser) c.push(['V_R (RMS)', n(r.VR), 'V', 'sefase arus'], ['V_L (RMS)', n(r.VL), 'V', 'mendahului 90°'], ['V_C (RMS)', n(r.VC), 'V', 'tertinggal 90°']);
  else c.push(['I_R', n(r.IR), 'A', 'fase 0° terhadap V'], ['I_L', n(r.IL), 'A', 'fase −90°'], ['I_C', n(r.IC), 'A', 'fase +90°']);
  c.push(['Faktor daya', n(r.PF), '', r.phi > 0.0087 ? 'lagging' : r.phi < -0.0087 ? 'leading' : 'unity'], ['Daya aktif P', n(r.P), 'W', ''], ['Daya reaktif Q', n(r.Q), 'var', 'induktif +, kapasitif −'], ['Daya semu S', n(r.S), 'VA', 'S² = P² + Q²'],
    ['Frekuensi resonansi f₀', n(r.f0), 'Hz', '1/(2π√LC)'], ['f − f₀', n(S.f - r.f0), 'Hz', Number.isFinite(r.f0) ? (S.f < r.f0 ? 'di bawah resonansi' : S.f > r.f0 ? 'di atas resonansi' : 'resonansi') : 'L atau C nonaktif']);
  $('#cards').innerHTML = c.map(([a, b, u, i]) => `<div class="card"><small>${a}</small><b>${b} ${u}</b><em>${i}</em></div>`).join('');
}

function steps() {
  const r = S.res, p = S.p, t = [];
  t.push(`ω = 2π·f = 2π·${n(p.f)} = ${n(r.w)} rad/s`);
  t.push(`X_L = ωL = ${n(r.w)}·${n(p.L)} = ${n(r.XL)} Ω${S.useL ? '' : ' (L nonaktif)'}`);
  t.push(`X_C = 1/(ωC) = 1/(${n(r.w)}·${n(p.C)}) = ${n(r.XC)} Ω${S.useC ? '' : ' (C nonaktif)'}`);
  if (r.mode === 'seri') {
    t.push(`Z = R + j(X_L − X_C) = ${n(p.R)} + j(${n(r.XL)} − ${n(r.XC)}) = ${n(p.R)} + j${n(r.X)} Ω`);
    t.push(`|Z| = √(R² + X²) = √(${n(p.R)}² + ${n(r.X)}²) = ${n(r.Z)} Ω`, `φ = atan2(X, R) = atan2(${n(r.X)}, ${n(p.R)}) = ${deg(r.phi)}°`);
    t.push(`I_RMS = V/|Z| = ${n(p.V)}/${n(r.Z)} = ${n(r.I)} A;  I_puncak = √2·I_RMS = ${n(r.Ipk)} A`);
    t.push(`V_R = I·R = ${n(r.VR)} V;  V_L = I·X_L = ${n(r.VL)} V;  V_C = I·X_C = ${n(r.VC)} V`, `V_s = √(V_R² + (V_L − V_C)²) = ${n(Math.hypot(r.VR, r.VL - r.VC))} V (jumlah fasor, bukan ${n(r.VR + r.VL + r.VC)} V)`);
  } else {
    t.push(`Y = 1/R + j(ωC − 1/(ωL)) = ${n(r.G)} + j${n(r.B)} S`, `|Y| = ${n(r.Y)} S;  Z_eq = 1/|Y| = ${n(r.Z)} Ω;  φ = −atan2(B, G) = ${deg(r.phi)}°`);
    t.push(`I_R = V/R = ${n(r.IR)} A;  I_L = V/(ωL) = ${n(r.IL)} A;  I_C = V·ωC = ${n(r.IC)} A`, `I_total = √(I_R² + (I_C − I_L)²) = ${n(r.I)} A (jumlah fasor, bukan ${n(r.IR + r.IL + r.IC)} A)`);
  }
  t.push(`PF = cos φ = ${n(r.PF)};  P = V·I·cosφ = ${n(r.P)} W;  Q = V·I·sinφ = ${n(r.Q)} var;  S = V·I = ${n(r.S)} VA`, `Cek: P² + Q² = ${n(r.P ** 2 + r.Q ** 2)} ≈ S² = ${n(r.S ** 2)}`);
  t.push(`f₀ = 1/(2π√(LC)) = ${n(r.f0)} Hz`);
  $('#steps').textContent = t.join('\n');
}

function formulas() {
  $('#formulas').innerHTML = S.mode === 'seri'
    ? 'Seri: Z = R + j(X<sub>L</sub> − X<sub>C</sub>); |Z| = √[R² + (X<sub>L</sub> − X<sub>C</sub>)²]; φ = atan2(X<sub>L</sub> − X<sub>C</sub>, R); I = V/|Z|; P = VI cosφ; Q = VI sinφ; S = VI; f₀ = 1/(2π√LC).'
    : 'Paralel: Y = 1/R + j(ωC − 1/(ωL)); Z<sub>eq</sub> = 1/Y; I<sub>total</sub> = V·Y (jumlah fasor I<sub>R</sub> + I<sub>L</sub> + I<sub>C</sub>); φ = sudut Z<sub>eq</sub> = −sudut Y; P = VI cosφ; f₀ = 1/(2π√LC) (B = 0).';
}

/* ---------- diagram rangkaian ---------- */
const INFO = {
  src: 'Sumber AC: v(t) = √2·V_RMS·sin(ωt). Nilai RMS adalah nilai efektif (setara DC dalam daya).',
  R: 'Resistor: tegangan sefase dengan arus; hambatan R tidak bergantung frekuensi dan mengubah energi menjadi panas.',
  L: 'Induktor: V mendahului I sebesar 90°; X_L = ωL naik jika f naik (menahan arus frekuensi tinggi).',
  C: 'Kapasitor: V tertinggal dari I sebesar 90°; X_C = 1/(ωC) turun jika f naik (menahan arus frekuensi rendah).'
};
let dots = [];
function sym(t, x, y, rot, id, label, on) {
  const body = { R: '<polyline points="0,0 8,0 14,-10 24,10 34,-10 44,10 50,0 60,0" fill="none"/>', L: '<path d="M0,0 H6 a8,8 0 0 1 16,0 a8,8 0 0 1 16,0 a8,8 0 0 1 16,0 H60" fill="none"/>', C: '<path d="M0,0 H26 M26,-14 V14 M34,-14 V14 M34,0 H60" fill="none"/>' }[t];
  const col = `var(--${t})`;
  return `<g data-c="${t}" id="${id}" tabindex="0" role="button" aria-label="${label}"><g transform="translate(${x},${y}) rotate(${rot})" stroke="${col}" stroke-width="3" opacity="${on ? 1 : .35}" ${on ? '' : 'stroke-dasharray="4 3"'}><rect class="bg" x="-2" y="-16" width="64" height="32" fill="var(--card)" stroke="none" rx="4"/>${body}</g></g>`;
}
function circuit() {
  const r = S.res, p = S.p, ser = r.mode === 'seri', svg = $('#circuit'); dots = [];
  const w = '<g stroke="var(--tx)" stroke-width="2" fill="none">';
  let h = `<g id="src" data-c="src" tabindex="0" role="button" aria-label="Sumber AC"><circle cx="50" cy="115" r="22" fill="var(--card)" stroke="var(--tx)" stroke-width="2"/><path d="M38,115 q6,-14 12,0 t12,0" stroke="var(--v)" stroke-width="2.5" fill="none"/></g>`;
  let lab = `<text x="50" y="152" text-anchor="middle">Sumber</text><text x="50" y="165" text-anchor="middle">${n(p.V)} V, ${n(p.f)} Hz</text>`;
  if (ser) {
    h = w + '<path d="M50,93 V50 H470 V190 H50 V137"/></g>' + h + sym('R', 110, 50, 0, 'cR', 'Resistor', true) + sym('L', 220, 50, 0, 'cL', 'Induktor', S.useL) + sym('C', 330, 50, 0, 'cC', 'Kapasitor', S.useC);
    if (!S.useL) h += '<line x1="220" y1="50" x2="280" y2="50" stroke="var(--tx)" stroke-width="2"/>';
    if (!S.useC) h += '<line x1="330" y1="50" x2="390" y2="50" stroke="var(--tx)" stroke-width="2"/>';
    lab += `<text x="140" y="82" text-anchor="middle">R = ${n(p.R)} Ω</text><text x="250" y="82" text-anchor="middle">${S.useL ? `L = ${n(S.L)} mH` : 'L: kawat'}</text><text x="250" y="96" text-anchor="middle">${S.useL ? `X_L = ${n(r.XL)} Ω` : ''}</text><text x="360" y="82" text-anchor="middle">${S.useC ? `C = ${n(S.Cc)} µF` : 'C: kawat'}</text><text x="360" y="96" text-anchor="middle">${S.useC ? `X_C = ${n(r.XC)} Ω` : ''}</text><text x="260" y="212" text-anchor="middle">i(t) positif: searah jarum jam · I = ${n(r.I)} A</text>`;
    [140, 250, 360].forEach(x => dots.push({ x, y: 190, vert: 0, amp: 14, ph: -r.phi }));
  } else {
    h = w + `<path d="M50,93 V50 H470 M50,137 V190 H470 M470,50 V190"/></g>` + h;
    const br = [['R', 140, 'cR', 'Resistor', true, 0, r.IR], ['L', 270, 'cL', 'Induktor', S.useL, Math.PI / 2, r.IL], ['C', 400, 'cC', 'Kapasitor', S.useC, -Math.PI / 2, r.IC]];
    const mx = Math.max(r.IR, r.IL, r.IC, 1e-12);
    br.forEach(([t, x, id, nm, on, ph, I]) => {
      h += `<g stroke="var(--tx)" stroke-width="2" fill="none"><path d="M${x},50 V${on ? 190 : 70}${on ? '' : ` M${x},170 V190`}"/></g>` + sym(t, x, 85, 90, id, nm, on).replace('translate(' + x + ',85)', `translate(${x},85)`);
      if (!on) h += `<text x="${x + 10}" y="125">terbuka</text>`;
      if (on) { dots.push({ x, y: 68, vert: 1, amp: 14 * I / mx, ph: ph - r.phi * 0 }); dots.push({ x, y: 168, vert: 1, amp: 14 * I / mx, ph }); }
      lab += `<text x="${x + 52 > 500 ? x - 4 : x + 52}" y="118" ${x + 52 > 500 ? 'text-anchor="end"' : ''}>${t === 'R' ? `R = ${n(p.R)} Ω` : t === 'L' ? `L = ${n(S.L)} mH` : `C = ${n(S.Cc)} µF`}</text><text x="${x + 52 > 500 ? x - 4 : x + 52}" y="132" ${x + 52 > 500 ? 'text-anchor="end"' : ''}>I = ${n(I)} A</text>`;
    });
    lab += `<text x="260" y="215" text-anchor="middle">Arus total I = ${n(r.I)} A (jumlah fasor)</text>`;
  }
  svg.innerHTML = h + lab + dots.map((_, i) => `<circle id="dot${i}" r="4.5" fill="var(--i)"/>`).join('');
  if (!ser) dots.forEach(d => d.ph = d.ph); // fase relatif terhadap v(t)
  svg.querySelectorAll('[data-c]').forEach(g => { const k = g.dataset.c; const f = () => { svg.querySelectorAll('[data-c]').forEach(x => x.classList.remove('sel')); g.classList.add('sel'); $('#info').textContent = INFO[k]; }; g.onclick = f; g.onkeydown = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); f(); } }; });
}

/* ---------- gelombang ---------- */
function wave() {
  const svg = $('#wave'), r = S.res, X0 = 30, W = 560, Y0 = 110, A = 80, TT = 4 * Math.PI;
  const path = fn => { let d = ''; for (let i = 0; i <= 240; i++) { const th = TT * i / 240; d += (i ? 'L' : 'M') + (X0 + W * th / TT).toFixed(1) + ',' + (Y0 - A * fn(th)).toFixed(1); } return d; };
  let h = `<line x1="${X0}" y1="${Y0}" x2="${X0 + W}" y2="${Y0}" stroke="var(--mut)"/><line x1="${X0}" y1="20" x2="${X0}" y2="200" stroke="var(--mut)"/>`;
  for (let k = 1; k <= 4; k++) h += `<text x="${X0 + W * k / 4}" y="${Y0 + 14}" text-anchor="middle">${k / 2}T</text>`;
  h += `<path d="${path(t => Math.sin(t))}" fill="none" stroke="var(--v)" stroke-width="2.5"/><path d="${path(t => Math.sin(t - r.phi))}" fill="none" stroke="var(--i)" stroke-width="2.5"/>`;
  h += `<text x="${X0 + 6}" y="16" fill="var(--v)" style="fill:var(--v)">— v(t) tegangan</text><text x="${X0 + 130}" y="16" style="fill:var(--i)">— i(t) arus (skala dinormalisasi)</text>`;
  h += `<line id="cur" y1="20" y2="200" stroke="var(--mut)" stroke-dasharray="4 3"/><circle id="cv" r="5" fill="var(--v)"/><circle id="ci" r="5" fill="var(--i)"/>`;
  svg.innerHTML = h;
  const dt = r.phi / r.w * 1e3;
  $('#waveInfo').innerHTML = `φ = ${deg(r.phi)}° ⇒ ${r.phi > 0.0087 ? 'arus tertinggal' : r.phi < -0.0087 ? 'arus mendahului' : 'arus sefase'} dari tegangan sejauh |Δt| = ${n(Math.abs(dt))} ms (T = ${n(1e3 / S.p.f)} ms).<br>V<sub>RMS</sub> = ${n(S.p.V)} V, V<sub>puncak</sub> = ${n(Math.SQRT2 * S.p.V)} V · I<sub>RMS</sub> = ${n(r.I)} A, I<sub>puncak</sub> = ${n(r.Ipk)} A<br><span id="inst"></span>`;
  S.wv = { X0, W, Y0, A, TT };
}

/* ---------- fasor ---------- */
function phasor() {
  const svg = $('#phasor'), r = S.res, p = S.p, ser = r.mode === 'seri', O = [150, 135];
  const vs = ser ? [['V_R', r.VR, 0, 'var(--R)', 'V'], ['V_L', 0, r.VL, 'var(--L)', 'V'], ['V_C', 0, -r.VC, 'var(--C)', 'V']] : [['I_R', r.IR, 0, 'var(--R)', 'A'], ['I_L', 0, -r.IL, 'var(--L)', 'A'], ['I_C', 0, r.IC, 'var(--C)', 'A']];
  const sx = vs.reduce((a, v) => a + v[1], 0), sy = vs.reduce((a, v) => a + v[2], 0);
  vs.push([ser ? 'V_s' : 'I_tot', sx, sy, 'var(--tx)', ser ? 'V' : 'A']);
  const m = Math.max(...vs.map(v => Math.max(Math.abs(v[1]), Math.abs(v[2]))), 1e-12), k = 100 / m;
  let h = `<defs><marker id="ah" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="context-stroke"/></marker></defs><line x1="10" y1="${O[1]}" x2="310" y2="${O[1]}" stroke="var(--bd)"/><line x1="${O[0]}" y1="10" x2="${O[0]}" y2="250" stroke="var(--bd)"/>`;
  vs.forEach(([nm, x, y, c, u], i) => { if (Math.hypot(x, y) < 1e-12 * m) return; const ex = O[0] + x * k, ey = O[1] - y * k; h += `<line x1="${O[0]}" y1="${O[1]}" x2="${ex}" y2="${ey}" stroke="${c}" stroke-width="${i === 3 ? 3.5 : 2.5}" marker-end="url(#ah)"/><text x="${ex + (x < 0 ? -4 : 4)}" y="${ey + (y > 0 ? -6 : 14)}" ${x < 0 ? 'text-anchor="end"' : ''} style="fill:${c}">${nm} = ${n(Math.hypot(x, y), 3)} ${u} ∠${n(Math.atan2(y, x) * D, 3)}°</text>`; });
  h += `<text x="12" y="${O[1] - 4}">${ser ? 'acuan: arus I (0°)' : 'acuan: tegangan V (0°)'}</text><text x="12" y="${O[1] + 14}">${ser ? 'φ = ' + deg(r.phi) + '° (V_s terhadap I)' : 'sudut I_tot = ' + deg(-r.phi) + '°'}</text>`;
  svg.innerHTML = h;
}

/* ---------- grafik frekuensi (log-log) ---------- */
function plot(id, curves, marks) {
  const svg = $(id), W = 420, H = 250, l = 48, b = 28, t = 10, rr = 10, pw = W - l - rr, ph = H - b - t;
  const ys = curves.flatMap(c => c.y).filter(v => v > 0 && isFinite(v));
  if (!ys.length) { svg.innerHTML = '<text x="20" y="40">Tidak ada data (komponen nonaktif).</text>'; return; }
  let a = Math.floor(Math.log10(Math.min(...ys)) - 0.05), z = Math.ceil(Math.log10(Math.max(...ys)) + 0.05); if (z - a < 1) z = a + 1;
  const X = f => l + pw * Math.log10(f) / 3, Y = v => t + ph * (1 - (Math.log10(v) - a) / (z - a));
  let h = `<rect x="${l}" y="${t}" width="${pw}" height="${ph}" fill="none" stroke="var(--bd)"/>`;
  [1, 10, 100, 1000].forEach(f => h += `<line x1="${X(f)}" y1="${t}" x2="${X(f)}" y2="${t + ph}" stroke="var(--bd)"/><text x="${X(f)}" y="${H - 12}" text-anchor="middle">${f}</text>`);
  for (let e = a; e <= z; e++) h += `<line x1="${l}" y1="${Y(10 ** e)}" x2="${l + pw}" y2="${Y(10 ** e)}" stroke="var(--bd)"/><text x="${l - 4}" y="${Y(10 ** e) + 4}" text-anchor="end">${n(10 ** e, 2)}</text>`;
  h += `<text x="${l + pw / 2}" y="${H - 1}" text-anchor="middle">frekuensi f (Hz, skala log)</text>`;
  marks.forEach(([f, txt, c]) => { if (f >= 1 && f <= 1000) h += `<line x1="${X(f)}" y1="${t}" x2="${X(f)}" y2="${t + ph}" stroke="${c}" stroke-dasharray="4 3"/><text x="${X(f) + 3}" y="${t + 12 + (c === 'var(--ac)' ? 12 : 0)}" style="fill:${c}">${txt}</text>`; });
  curves.forEach((c, j) => {
    let d = ''; c.y.forEach((v, i) => { if (v > 0 && isFinite(v)) d += (d ? 'L' : 'M') + X(c.x[i]).toFixed(1) + ',' + Math.min(t + ph, Math.max(t, Y(v))).toFixed(1); });
    h += `<path d="${d}" fill="none" stroke="${c.c}" stroke-width="2.5"/><text x="${l + 6}" y="${t + ph - 6 - 13 * j}" style="fill:${c.c}">— ${c.n}</text>`;
    if (c.cur > 0 && isFinite(c.cur)) h += `<circle cx="${X(S.p.f)}" cy="${Y(c.cur)}" r="4.5" fill="${c.c}"/>`;
  });
  svg.innerHTML = h;
}
function charts() {
  const r = S.res, p = S.p, fs = Array.from({ length: 150 }, (_, i) => 10 ** (3 * i / 149)), ser = r.mode === 'seri';
  const rs = fs.map(f => RLC.calc(S.mode, { ...p, f }));
  const marks = [[r.f0, 'f₀', 'var(--R)'], [p.f, 'f kerja', 'var(--ac)']];
  $('#t3').textContent = ser ? '|Z| terhadap frekuensi (seri)' : '|Z_eq| terhadap frekuensi (paralel)';
  plot('#ch3', [{ x: fs, y: rs.map(q => q.Z), c: 'var(--v)', n: ser ? '|Z|' : '|Z_eq|', cur: r.Z }], marks);
  if (ser) {
    $('#t4').textContent = 'Reaktansi X_L dan X_C terhadap frekuensi';
    plot('#ch4', [{ x: fs, y: rs.map(q => q.XL), c: 'var(--L)', n: 'X_L', cur: r.XL }, { x: fs, y: rs.map(q => q.XC), c: 'var(--C)', n: 'X_C', cur: r.XC }], marks);
    $('#n4').textContent = `Perpotongan X_L = X_C terjadi di f₀ = ${n(r.f0)} Hz: reaktansi saling meniadakan, Z = R (minimum), φ = 0°.${S.useL && S.useC ? '' : ' (Salah satu komponen nonaktif: tidak ada perpotongan.)'}`;
  } else {
    $('#t4').textContent = 'Arus total dan arus cabang terhadap frekuensi';
    plot('#ch4', [{ x: fs, y: rs.map(q => q.I), c: 'var(--v)', n: 'I_total', cur: r.I }, { x: fs, y: rs.map(q => q.IL), c: 'var(--L)', n: 'I_L', cur: r.IL }, { x: fs, y: rs.map(q => q.IC), c: 'var(--C)', n: 'I_C', cur: r.IC }], marks);
    $('#n4').textContent = 'Pada resonansi paralel ideal I_L = I_C berlawanan fase sehingga saling meniadakan; arus total minimum = V/R dan |Z_eq| maksimum = R.';
  }
}

/* ---------- animasi ---------- */
function draw() {
  const r = S.res, w = S.wv; if (!r || !w) return;
  const th = S.th, x = w.X0 + w.W * th / w.TT, vv = Math.sin(th), ii = Math.sin(th - r.phi);
  $('#cur').setAttribute('x1', x); $('#cur').setAttribute('x2', x);
  $('#cv').setAttribute('cx', x); $('#cv').setAttribute('cy', w.Y0 - w.A * vv); $('#ci').setAttribute('cx', x); $('#ci').setAttribute('cy', w.Y0 - w.A * ii);
  const inst = $('#inst'); if (inst) inst.textContent = `Nilai sesaat: v = ${n(Math.SQRT2 * S.p.V * vv, 3)} V, i = ${n(r.Ipk * ii, 3)} A`;
  dots.forEach((d, i) => { const e = document.getElementById('dot' + i); if (!e) return; const o = d.amp * Math.sin(th - (S.mode === 'seri' ? r.phi : d.ph)); e.setAttribute('cx', d.vert ? d.x : d.x + o); e.setAttribute('cy', d.vert ? d.y + o : d.y); });
}
let last = 0;
function frame(ts) {
  const dt = Math.min(0.05, (ts - last) / 1e3 || 0); last = ts;
  if (S.run && S.anim && !document.hidden) { S.th = (S.th + dt * S.speed * Math.PI) % (4 * Math.PI); draw(); }
  requestAnimationFrame(frame);
}

/* ---------- tombol ---------- */
const setMode = m => { S.mode = m; $('#bSeri').classList.toggle('on', m === 'seri'); $('#bPar').classList.toggle('on', m === 'paralel'); update(); };
$('#bSeri').onclick = () => setMode('seri'); $('#bPar').onclick = () => setMode('paralel');
$('#useL').onchange = e => { S.useL = e.target.checked; update(); }; $('#useC').onchange = e => { S.useC = e.target.checked; update(); };
const playLbl = () => { $('#bPlay').textContent = S.run ? '⏸ Jeda' : '▶ Mulai'; };
$('#bPlay').onclick = () => { S.run = !S.run; playLbl(); };
$('#bReset').onclick = () => { S.th = 0; draw(); };
$('#bDef').onclick = () => { Object.assign(S, DEF, { useL: true, useC: true, th: 0 }); $('#useL').checked = $('#useC').checked = true; syncs.forEach(f => f()); update(); };
$('#bAnim').onclick = e => { S.anim = !S.anim; e.target.classList.toggle('on', S.anim); e.target.textContent = 'Animasi: ' + (S.anim ? 'ON' : 'OFF'); };
$('#speed').oninput = e => { S.speed = +e.target.value; };
$('#bForm').onclick = e => { const o = e.target.classList.toggle('on'); $('#formulas').style.display = o ? '' : 'none'; };
$('#bTheory').onclick = e => { const o = e.target.classList.toggle('on'); $('#theory').style.display = o ? '' : 'none'; };
$('#theme').onclick = () => { const d = document.documentElement; d.dataset.theme = d.dataset.theme === 'dark' ? 'light' : 'dark'; };
if (matchMedia('(prefers-color-scheme: dark)').matches) document.documentElement.dataset.theme = 'dark';

/* ---------- tabel pengamatan + CSV ---------- */
function renderLog() {
  $('#logBody').innerHTML = S.log.map((q, i) => `<tr><td>${i + 1}</td>${q.slice(0, 10).map(v => `<td>${v}</td>`).join('')}<td><input type="text" aria-label="Kesimpulan ${i + 1}" value="${q[10]}" data-i="${i}" style="width:100%;min-width:120px"></td></tr>`).join('');
  document.querySelectorAll('#logBody input').forEach(i => i.oninput = () => { S.log[+i.dataset.i][10] = i.value; });
}
$('#bLog').onclick = () => { const r = S.res; S.log.push([S.mode, S.V, S.f, S.R, S.L, S.Cc, n(r.Z), deg(r.phi), n(r.I), '']); renderLog(); };
$('#bClr').onclick = () => { S.log = []; renderLog(); };
$('#bCsv').onclick = () => {
  const head = ['No', 'Mode', 'V_V', 'f_Hz', 'R_ohm', 'L_mH', 'C_uF', 'Z_ohm', 'phi_deg', 'I_A', 'Kesimpulan'];
  const csv = [head, ...S.log.map((q, i) => [i + 1, ...q])].map(r => r.map(v => '"' + String(v).replace(/"/g, '""') + '"').join(';')).join('\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv' })); a.download = 'pengamatan_rlc.csv'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
};

/* ---------- kuis ---------- */
const Q = [
  ['Berapa X_L untuk L = 0,1 H pada f = 50 Hz?', ['3,14 Ω', '31,4 Ω', '314 Ω', '0,5 Ω'], 1, 'X_L = 2πfL = 2π·50·0,1 ≈ 31,4 Ω.'],
  ['Berapa X_C untuk C = 100 µF pada f = 50 Hz?', ['318 Ω', '3,18 Ω', '31,8 Ω', '0,03 Ω'], 2, 'X_C = 1/(2π·50·100·10⁻⁶) ≈ 31,8 Ω. Ingat µF = 10⁻⁶ F.'],
  ['Pada RLC seri, jika R = 100 Ω dan X_L − X_C = 100 Ω, berapa |Z|?', ['200 Ω', '100 Ω', '141 Ω', '0 Ω'], 2, '|Z| = √(100² + 100²) ≈ 141 Ω; R dan X dijumlah secara kuadrat (fasor).'],
  ['V = 12 V dan |Z| = 100 Ω. Arus RMS?', ['8,33 A', '0,12 A', '1,2 A', '0,17 A'], 1, 'I = V/|Z| = 12/100 = 0,12 A (RMS).'],
  ['φ bernilai positif berarti…', ['arus mendahului tegangan', 'arus tertinggal dari tegangan', 'rangkaian resistif murni', 'terjadi resonansi'], 1, 'φ > 0 berarti X_L > X_C (induktif): arus tertinggal (lagging).'],
  ['Faktor daya rangkaian resistif murni adalah…', ['0', '0,5', '1', '∞'], 2, 'φ = 0° sehingga cos φ = 1 (unity).'],
  ['f₀ untuk L = 0,1 H dan C = 100 µF kira-kira…', ['5,03 Hz', '50,3 Hz', '503 Hz', '159 Hz'], 1, 'f₀ = 1/(2π√(0,1·10⁻⁴)) ≈ 50,3 Hz.'],
  ['Hubungan yang benar antara daya AC adalah…', ['S = P + Q', 'S² = P² + Q²', 'P = S + Q', 'Q = P·S'], 1, 'P (aktif) dan Q (reaktif) saling tegak lurus pada segitiga daya, sehingga S² = P² + Q².'],
  ['Arus total RLC paralel dihitung dengan…', ['menjumlahkan magnitudo arus cabang', 'mengalikan arus cabang', 'penjumlahan fasor arus cabang', 'mengambil arus terbesar'], 2, 'Arus cabang berbeda fase (0°, −90°, +90°), jadi dijumlahkan sebagai fasor: I = √(I_R² + (I_C − I_L)²).'],
  ['Jika C diperbesar 4 kali (L tetap), f₀ menjadi…', ['2 kali', '4 kali', '½ kali', '¼ kali'], 2, 'f₀ ∝ 1/√C, sehingga C × 4 membuat f₀ menjadi ½ kali.']
];
let score = 0, done = 0;
$('#quiz').innerHTML = Q.map((q, i) => `<div class="q"><b>${i + 1}. ${q[0]}</b>${q[1].map((o, j) => `<button data-q="${i}" data-o="${j}">${String.fromCharCode(65 + j)}. ${o}</button>`).join('')}<p class="fb" id="fb${i}" aria-live="polite"></p></div>`).join('');
$('#quiz').onclick = e => {
  const b = e.target.closest('button'); if (!b || b.parentNode.dataset.done) return;
  const i = +b.dataset.q, j = +b.dataset.o, ok = j === Q[i][2]; b.parentNode.dataset.done = 1; done++; if (ok) score++;
  b.classList.add(ok ? 'ok' : 'no'); if (!ok) b.parentNode.querySelector(`[data-o="${Q[i][2]}"]`).classList.add('ok');
  $('#fb' + i).textContent = (ok ? '✔ Benar. ' : '✘ Kurang tepat. ') + Q[i][3];
  $('#score').textContent = `Terjawab ${done}/${Q.length} · Skor ${score}`;
};

syncs.forEach(f => f()); playLbl(); update(); requestAnimationFrame(frame);
})();
