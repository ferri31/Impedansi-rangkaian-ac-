# Simulasi Hukum Impedansi RLC pada Rangkaian Listrik AC

Simulasi interaktif (HTML + CSS + JavaScript murni + SVG) untuk mempelajari R, L, C, impedansi, fase, daya, dan resonansi pada rangkaian AC **seri** dan **paralel**. Tanpa backend; berjalan di browser laptop dan HP.

## Tujuan pembelajaran
Memahami X_L, X_C, impedansi kompleks, sudut fase, faktor daya, daya AC, dan resonansi serta perbedaan RLC seri vs paralel.

## Fitur
Diagram rangkaian SVG (klik komponen = penjelasan), kontrol slider + input angka, kartu hasil + langkah perhitungan, gelombang v(t)/i(t) animasi, diagram fasor, grafik |Z| dan reaktansi/arus vs frekuensi, eksperimen A–E dengan tabel + ekspor CSV, 10 soal kuis, tema terang/gelap.

## Struktur file
- `index.html` – struktur halaman
- `style.css` – tampilan responsif
- `calc.js` – fungsi perhitungan murni (tanpa DOM, dapat diuji)
- `script.js` – antarmuka, grafik, animasi, kuis
- `tests/test.js` – pengujian fisika (`node tests/test.js`)
- `assets/` – folder aset lokal (kosong)

## Menjalankan lokal
Buka `index.html` di browser (klik dua kali). Atau: `python -m http.server 8000` lalu buka http://localhost:8000.

## Publikasi di GitHub Pages
1. Buat akun di github.com, lalu **New repository** (mis. `rlc-impedance-simulator`, Public).
2. **Add file → Upload files**, unggah `index.html`, `style.css`, `calc.js`, `script.js`, `README.md`, folder `tests` (index.html harus di root repositori) → **Commit changes**.
3. **Settings → Pages**. Pada *Build and deployment*, Source: **Deploy from a branch**; Branch: **main**, folder **/ (root)** → **Save**.
4. Tunggu 1–3 menit; alamat: `https://USERNAME.github.io/rlc-impedance-simulator/` (tampil di halaman Pages setelah selesai).
5. Memperbarui: unggah ulang/edit file lalu commit; tunggu build selesai dan muat ulang (Ctrl+F5).

## Jika halaman tidak muncul
- 404: pastikan `index.html` ada di root dan nama file huruf kecil semua.
- Halaman kosong/tak responsif: buka Console (F12), pastikan `calc.js` dan `script.js` terunggah.
- Tampilan lama: muat ulang paksa (Ctrl+F5).
